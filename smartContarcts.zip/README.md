# SWAP NOMIC

pnpm install

## Deploy

pnpm exec hardhat --network base deploy --tags AMM
