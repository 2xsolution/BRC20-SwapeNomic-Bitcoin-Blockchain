const { default: config } = require('@sushiswap/eslint-config/hardhat')

module.exports = config
