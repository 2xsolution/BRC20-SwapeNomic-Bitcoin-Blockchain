export const backgroundColor = "#0A0A0A";
