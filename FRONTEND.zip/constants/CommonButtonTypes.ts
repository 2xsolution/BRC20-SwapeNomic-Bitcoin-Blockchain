export enum CommonButtonTypes {
  gradient,
  simple,
}
