import type { NextPage } from "next";
import Container from "../components/Container";

const SMB: NextPage = () => {
  return (
    <Container title="SMB">
      <div>SMB</div>
    </Container>
  );
};

export default SMB;
