import styled from "styled-components";

export const LeftSideHeaderConatiner = styled.div`
  display: flex;
`;
