import styled from "styled-components";

export const TopFarmsCollectionContainer = styled.div`
  display: flex;
  flex-direction: row;
  margin: 20px 0px 20px 0px;
  align-items: center;
  justify-content: space-between;
  height: 220px;
`;
